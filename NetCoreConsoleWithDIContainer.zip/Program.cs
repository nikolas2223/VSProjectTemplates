﻿using LightInject;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var builder = new ConfigurationBuilder();
            BuildConfig(builder);

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(builder.Build())
                .Enrich.FromLogContext()
                .WriteTo.Console()
                .WriteTo.File(Path.Combine(Directory.GetCurrentDirectory(), "appLog.log"))
                .CreateLogger();

            Log.Logger.Information("App starting");

            var host = Host.CreateDefaultBuilder()
                .UseLightInject()
                .ConfigureAppConfiguration((context, builder) => BuildConfig(builder))
                .ConfigureContainer<IServiceContainer>((context, container) =>
                {
                    container.RegisterFrom<CompositionRoot>();
                })
                .UseSerilog()
                .Build();

            Log.Logger.Information("App started");

            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var templateClass = services.GetRequiredService<ITemplateRunClass>();
                templateClass.Run();
            }
        }

        static void BuildConfig(IConfigurationBuilder builder)
        {
            builder.SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", optional: true)
                .AddEnvironmentVariables();
        }
    }
}