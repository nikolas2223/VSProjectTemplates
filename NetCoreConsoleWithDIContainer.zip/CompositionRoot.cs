﻿using LightInject;

namespace $safeprojectname$
{
    public class CompositionRoot : ICompositionRoot
    {
        public void Compose(IServiceRegistry serviceRegistry)
        {
            serviceRegistry.RegisterTransient<ITemplateRunClass, TemplateRunClass>();
        }
    }
}