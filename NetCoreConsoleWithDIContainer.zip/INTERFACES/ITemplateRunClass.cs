﻿namespace $safeprojectname$
{
    public interface ITemplateRunClass
    {
        void Run();
    }
}